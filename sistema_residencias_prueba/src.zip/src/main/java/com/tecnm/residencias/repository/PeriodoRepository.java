package com.tecnm.residencias.repository;

import com.tecnm.residencias.entity.PeriodoAcademico;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PeriodoRepository extends JpaRepository<PeriodoAcademico, Long> {
    List<PeriodoAcademico> findByActivoTrue();

}