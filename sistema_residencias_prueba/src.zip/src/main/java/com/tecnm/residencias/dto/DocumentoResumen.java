package com.tecnm.residencias.dto;

import java.time.LocalDateTime;

public class DocumentoResumen {
    private Long id;
    private String nombre;
    private LocalDateTime fechaSubida;
    private String estado;
    private String badgeClass;

    public DocumentoResumen(Long id, String nombre, LocalDateTime fechaSubida, Boolean aceptado) {
        this.id = id;
        this.nombre = nombre;
        this.fechaSubida = fechaSubida;
        this.estado = (aceptado == null) ? "Pendiente" : aceptado ? "Aceptado" : "Rechazado";
        this.badgeClass = (aceptado == null) ? "bg-warning text-dark" : aceptado ? "bg-success" : "bg-danger";
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDateTime getFechaSubida() {
        return fechaSubida;
    }

    public String getEstado() {
        return estado;
    }

    public String getBadgeClass() {
        return badgeClass;
    }
}
