package com.tecnm.residencias.controller;

import com.tecnm.residencias.entity.Alumno;
import com.tecnm.residencias.entity.Documento;
import com.tecnm.residencias.entity.Usuario;
import com.tecnm.residencias.repository.AlumnoRepository;
import com.tecnm.residencias.repository.DocumentoRepository;
import com.tecnm.residencias.repository.UsuarioRepository;
import com.tecnm.residencias.service.DocumentoGeneradorService;
import com.tecnm.residencias.service.NotificacionService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Controller
@RequestMapping("/documentos")
public class DocumentoController {

    @Autowired
    private DocumentoRepository documentoRepo;
    @Autowired
    private AlumnoRepository alumnoRepo;
    @Autowired
    private UsuarioRepository usuarioRepo;
    @Autowired
    private NotificacionService notificacionService;
    @Autowired
    private DocumentoGeneradorService documentoGeneradorService;


    // SUBIR MÚLTIPLES DOCUMENTOS
    @PostMapping("/subir")
    public String subir(@RequestParam("archivo") List<MultipartFile> archivos, Authentication auth) throws IOException {
        Usuario usuario = usuarioRepo.findByCorreo(auth.getName()).orElse(null);
        if (usuario == null || archivos.isEmpty()) return "redirect:/mi_perfil";

        Alumno alumno = alumnoRepo.findByUsuario(usuario);

        for (MultipartFile archivo : archivos) {
            if (!archivo.isEmpty()) {
                Documento doc = new Documento();
                doc.setNombre(archivo.getOriginalFilename());
                doc.setDatos(archivo.getBytes());
                doc.setAceptado(null);
                doc.setAlumno(alumno);
                doc.setPeriodo(alumno.getPeriodo()); // Asignar el periodo del alumno
                documentoRepo.save(doc);
            }
        }

        return "redirect:/mi_perfil";
    }

    // DESCARGAR DOCUMENTO
    @Transactional(readOnly = true)
    @GetMapping("/descargar/{id}")
    public ResponseEntity<Resource> descargar(@PathVariable Long id) {
        Documento doc = documentoRepo.findById(id).orElse(null);
        if (doc == null || doc.getDatos() == null) return ResponseEntity.notFound().build();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + doc.getNombre() + "\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new ByteArrayResource(doc.getDatos()));
    }

    // ELIMINAR DOCUMENTO
    @PostMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id) {
        documentoRepo.findById(id).ifPresent(documentoRepo::delete);
        return "redirect:/mi_perfil";
    }

    // EDITAR (REEMPLAZAR) DOCUMENTO
    @PostMapping("/editar/{id}")
    public String editar(@PathVariable Long id, @RequestParam("archivo") MultipartFile archivo) throws IOException {
        Documento doc = documentoRepo.findById(id).orElse(null);
        if (doc != null && !archivo.isEmpty()) {
            doc.setNombre(archivo.getOriginalFilename());
            doc.setDatos(archivo.getBytes());
            doc.setAceptado(null);
            documentoRepo.save(doc);
        }
        return "redirect:/mi_perfil";
    }

    // ACEPTAR DOCUMENTO (CON NOTIFICACIÓN)
    @PostMapping("/aceptar/{id}")
    public String aceptar(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        Documento doc = documentoRepo.findById(id).orElse(null);

        if (doc == null) {
            redirectAttributes.addFlashAttribute("mensaje", "Error: documento no encontrado.");
            return "redirect:/panel"; // Puedes cambiar a donde sea más apropiado
        }

        doc.setAceptado(true);
        documentoRepo.save(doc);

        String mensaje = String.format("Tu documento \"%s\" ha sido ACEPTADO.", doc.getNombre());
        notificacionService.crear(doc.getAlumno(), mensaje);

        redirectAttributes.addFlashAttribute("mensaje", "Documento aceptado correctamente.");
        return "redirect:/alumnos/" + doc.getAlumno().getId() + "/documentos";
    }


    @PostMapping("/rechazar/{id}")
    public String rechazarDocumento(
            @PathVariable Long id,
            @RequestParam("motivo") String motivo,
            @RequestParam("fechaLimite") String fechaLimite,
            RedirectAttributes redirectAttributes
    ) {
        Documento doc = documentoRepo.findById(id).orElse(null);
        if (doc != null) {
            doc.setAceptado(false);
            documentoRepo.save(doc);

            String mensaje = String.format("Tu documento \"%s\" fue RECHAZADO.\nMotivo: %s.\nPuedes volver a subirlo antes del %s.",
                    doc.getNombre(),
                    motivo != null && !motivo.isBlank() ? motivo : "Sin especificar",
                    fechaLimite != null && !fechaLimite.isBlank() ? fechaLimite : "Sin fecha límite"
            );

            notificacionService.crear(doc.getAlumno(), mensaje);
            redirectAttributes.addFlashAttribute("mensaje", "Documento rechazado con observación.");
        }
        return "redirect:/alumnos/" + (doc != null ? doc.getAlumno().getId() : 0) + "/documentos";
    }


    // VISTA PREVIA INLINE (PARA MODAL)
    @GetMapping("/ver/{id}")
    @Transactional(readOnly = true)
    public void verDocumento(@PathVariable Long id, HttpServletResponse response) throws IOException {
        Documento doc = documentoRepo.findById(id).orElse(null);
        if (doc == null || doc.getDatos() == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }

        String tipo = "application/octet-stream";
        String nombre = doc.getNombre().toLowerCase();

        if (nombre.endsWith(".pdf")) {
            tipo = "application/pdf";
        } else if (nombre.endsWith(".doc") || nombre.endsWith(".docx") || nombre.endsWith(".odt")) {
            tipo = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        }

        response.setContentType(tipo);
        response.setHeader("Content-Disposition", "inline; filename=\"" + doc.getNombre() + "\"");
        response.getOutputStream().write(doc.getDatos());
    }

    @GetMapping("/todos")
    public String verTodosLosDocumentos(HttpSession session, Model model) {
        Long periodoId = (Long) session.getAttribute("periodoActivo");
        if (periodoId == null) {
            return "redirect:/?error=periodo";
        }

        List<Documento> documentos = documentoRepo.findByPeriodoId(periodoId);
        model.addAttribute("documentos", documentos);
        return "admin_documentos";
    }

    @GetMapping("/documentos-admin")
    public String verDocumentosAdmin(HttpSession session, Model model) {
        Long periodoId = (Long) session.getAttribute("periodoActivo");
        if (periodoId == null) {
            return "redirect:/?error=periodo";
        }

        List<Documento> documentos = documentoRepo.findByPeriodoId(periodoId); // ✅ SÓLO DEL PERIODO ACTIVO
        model.addAttribute("documentos", documentos);
        return "documentos_admin"; // 👈 Esta es la vista que ya tienes
    }




    @PostMapping("/documentos/generar")
    public String generarDocumento(
            @RequestParam String carrera,
            @RequestParam("tipo") String tipoDocumento,
            @RequestParam(value = "plantilla", required = false) MultipartFile plantilla,
            RedirectAttributes redirectAttributes) {

        try {
            List<Alumno> alumnos = alumnoRepo.findByCarreraIgnoreCase(carrera);
            if (alumnos.isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "No hay alumnos registrados en esa carrera.");
                return "redirect:/documentos";
            }

            // Obtener InputStream de plantilla (personalizada o por defecto)
            InputStream plantillaInputStream;
            if (plantilla != null && !plantilla.isEmpty()) {
                plantillaInputStream = plantilla.getInputStream();
            } else {
                plantillaInputStream = getClass().getResourceAsStream("/plantillas/plantilla-default.docx");
                if (plantillaInputStream == null) {
                    redirectAttributes.addFlashAttribute("error", "No se encontró la plantilla por defecto.");
                    return "redirect:/documentos";
                }
            }

            // Llamar al servicio con la nueva lógica
            Path archivoGenerado = documentoGeneradorService.generarParaCarrera(tipoDocumento, alumnos, plantillaInputStream);

            redirectAttributes.addFlashAttribute("mensaje", "Documento generado correctamente: " + archivoGenerado.getFileName());
        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "Error al generar el documento: " + e.getMessage());
        }

        return "redirect:/documentos";
    }

}

