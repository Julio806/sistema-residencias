package com.tecnm.residencias;

import com.tecnm.residencias.entity.Usuario;
import com.tecnm.residencias.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class ResidenciasApplication {

	public static void main(String[] args) {
		SpringApplication. run(ResidenciasApplication.class, args);
	}
}

