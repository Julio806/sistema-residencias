package com.tecnm.residencias.service;

import com.tecnm.residencias.entity.Alumno;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class DocumentoGeneradorService {

    public XWPFDocument generarDocumentoDesdePlantilla(InputStream plantilla, Alumno alumno) throws IOException {
        XWPFDocument doc = new XWPFDocument(plantilla);

        for (XWPFParagraph p : doc.getParagraphs()) {
            for (XWPFRun run : p.getRuns()) {
                String text = run.getText(0);
                if (text != null) {
                    text = text.replace("{{NOMBRE}}", alumno.getNombres() + " " + alumno.getApellidos());
                    text = text.replace("{{CARRERA}}", alumno.getCarrera());
                    text = text.replace("{{CONTROL}}", alumno.getNumeroControl());
                    run.setText(text, 0);
                }
            }
        }

        return doc;
    }

    public void copiarParrafo(XWPFParagraph source, XWPFParagraph target) {
        target.setAlignment(source.getAlignment());
        for (XWPFRun run : source.getRuns()) {
            XWPFRun newRun = target.createRun();
            newRun.setText(run.text());
            newRun.setBold(run.isBold());
            newRun.setItalic(run.isItalic());
            newRun.setUnderline(run.getUnderline());
            newRun.setFontSize(run.getFontSize());
            newRun.setFontFamily(run.getFontFamily());
            newRun.setColor(run.getColor());
        }
    }

    public void copiarTabla(XWPFTable source, XWPFTable target) {
        for (XWPFTableRow row : source.getRows()) {
            XWPFTableRow newRow = target.createRow();
            for (int i = 0; i < row.getTableCells().size(); i++) {
                String text = row.getCell(i).getText();
                if (newRow.getTableCells().size() > i) {
                    newRow.getCell(i).setText(text);
                } else {
                    newRow.addNewTableCell().setText(text);
                }
            }
        }
        target.removeRow(0);
    }
    public void reemplazarCampos(XWPFDocument doc, Alumno alumno) {
        for (XWPFParagraph paragraph : doc.getParagraphs()) {
            for (XWPFRun run : paragraph.getRuns()) {
                String text = run.getText(0);
                if (text != null) {
                    text = text.replace("{{NOMBRE}}", alumno.getNombres() + " " + alumno.getApellidos())
                            .replace("{{CONTROL}}", alumno.getNumeroControl())
                            .replace("{{CARRERA}}", alumno.getCarrera())
                            .replace("{{PROYECTO}}", alumno.getNombreProyecto() != null ? alumno.getNombreProyecto() : "");
                    run.setText(text, 0);
                }
            }
        }

        // También reemplaza en tablas
        for (XWPFTable table : doc.getTables()) {
            for (XWPFTableRow row : table.getRows()) {
                for (XWPFTableCell cell : row.getTableCells()) {
                    for (XWPFParagraph p : cell.getParagraphs()) {
                        for (XWPFRun run : p.getRuns()) {
                            String text = run.getText(0);
                            if (text != null) {
                                text = text.replace("{{NOMBRE}}", alumno.getNombres() + " " + alumno.getApellidos())
                                        .replace("{{CONTROL}}", alumno.getNumeroControl())
                                        .replace("{{CARRERA}}", alumno.getCarrera())
                                        .replace("{{PROYECTO}}", alumno.getNombreProyecto() != null ? alumno.getNombreProyecto() : "");
                                run.setText(text, 0);
                            }
                        }
                    }
                }
            }
        }
    }


    public Path generarParaCarrera(String tipo, List<Alumno> alumnos, InputStream plantillaStreamOriginal) throws IOException {
        if (alumnos.isEmpty()) throw new IllegalArgumentException("Lista de alumnos vacía");

        // Leemos el contenido original una sola vez
        byte[] plantillaBytes = plantillaStreamOriginal.readAllBytes();

        XWPFDocument documentoFinal = new XWPFDocument();

        for (Alumno alumno : alumnos) {
            try (InputStream plantillaStream = new java.io.ByteArrayInputStream(plantillaBytes)) {
                XWPFDocument plantillaAlumno = new XWPFDocument(plantillaStream);

                reemplazarCampos(plantillaAlumno, alumno);

                for (IBodyElement elem : plantillaAlumno.getBodyElements()) {
                    if (elem instanceof XWPFParagraph p) {
                        XWPFParagraph nuevo = documentoFinal.createParagraph();
                        copiarParrafo(p, nuevo);
                    } else if (elem instanceof XWPFTable t) {
                        XWPFTable nueva = documentoFinal.createTable();
                        copiarTabla(t, nueva);
                    }
                }

                documentoFinal.createParagraph().setPageBreak(true);
            }
        }

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String nombreArchivo = tipo.toUpperCase() + "_Carrera_" + alumnos.get(0).getCarrera().replaceAll("\\s+", "") + "_" + timestamp + ".docx";

        Path salida = Paths.get("documentos_generados", nombreArchivo);
        Files.createDirectories(salida.getParent());

        try (OutputStream out = Files.newOutputStream(salida)) {
            documentoFinal.write(out);
        }

        return salida;
    }


}
