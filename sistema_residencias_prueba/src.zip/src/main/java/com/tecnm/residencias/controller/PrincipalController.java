package com.tecnm.residencias.controller;

import com.tecnm.residencias.dto.CarreraCantidadDTO;
import com.tecnm.residencias.dto.DocumentoResumen;
import com.tecnm.residencias.entity.*;
import com.tecnm.residencias.repository.*;
import com.tecnm.residencias.service.DocumentoService;
import com.tecnm.residencias.service.NotificacionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

@Controller
public class PrincipalController {

    @Autowired private AlumnoRepository alumnoRepo;
    @Autowired private AlumnoRepository alumnoRepository;
    @Autowired private PeriodoRepository periodoRepository;
    @Autowired private PeriodoRepository periodoRepo;
    @Autowired private UsuarioRepository usuarioRepo;
    @Autowired private RolRepository rolRepo;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private DocumentoService documentoService;
    @Autowired private DocumentoRepository documentoRepo;
    @Autowired private NotificacionService notificacionService;

    @GetMapping("/")
    public String mostrarSelectorPeriodos(Model model) {
        List<PeriodoAcademico> periodos = periodoRepository.findByActivoTrue();
        model.addAttribute("periodos", periodos);
        return "dashboard";
    }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/registrar")
    public String mostrarFormulario(Model model) {
        model.addAttribute("alumno", new Alumno());
        model.addAttribute("periodos", periodoRepo.findAll());
        return "registrarAlumno";
    }

    @PostMapping("/guardarAlumno")
    public String guardarAlumno(@ModelAttribute Alumno alumno,
                                @RequestParam String correo,
                                RedirectAttributes redirectAttributes) {

        if (!correo.endsWith("@fcomalapa.tecnm.mx")) {
            redirectAttributes.addFlashAttribute("error", "El correo debe ser institucional (@fcomalapa.tecnm.mx)");
            return "redirect:/panel";
        }

        if (usuarioRepo.existsByCorreo(correo)) {
            redirectAttributes.addFlashAttribute("error", "Ya existe un usuario con ese correo.");
            return "redirect:/panel";
        }

        Rol rolAlumno = rolRepo.findByNombre("ALUMNO").orElse(null);
        if (rolAlumno == null) {
            redirectAttributes.addFlashAttribute("error", "El rol ALUMNO no está configurado.");
            return "redirect:/panel";
        }

        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setCorreo(correo);
        nuevoUsuario.setClave(passwordEncoder.encode("1234"));
        nuevoUsuario.setRol(rolAlumno);
        nuevoUsuario.setActivo(true);
        usuarioRepo.save(nuevoUsuario);

        alumno.setUsuario(nuevoUsuario);
        alumnoRepo.save(alumno);

        redirectAttributes.addFlashAttribute("mensaje", "Alumno registrado correctamente con usuario.");
        return "redirect:/panel";
    }

    @GetMapping("/alumnos")
    public String verAlumnos(Model model) {
        model.addAttribute("alumnos", alumnoRepo.findAll());
        return "listaAlumnos";
    }

    @GetMapping("/panel")
    public String panel(@RequestParam(value = "buscar", required = false) String buscar,
                        HttpSession session,
                        Model model) {

        // Validar periodoActivo de sesión
        Object rawPeriodo = session.getAttribute("periodoActivo");
        Long periodoId = null;

        if (rawPeriodo instanceof Long) {
            periodoId = (Long) rawPeriodo;
        } else {
            return "redirect:/seleccionar-periodo?error=falta_periodo";
        }

        // Obtener alumnos filtrados por periodo y búsqueda
        List<Alumno> alumnos;

        if (buscar != null && !buscar.isEmpty()) {
            alumnos = alumnoRepo.findByFiltroYPeriodo(buscar.toLowerCase(), periodoId);
        } else {
            alumnos = alumnoRepo.findByPeriodoId(periodoId);
        }

        model.addAttribute("alumnos", alumnos);
        model.addAttribute("buscar", buscar);
        model.addAttribute("alumno", new Alumno());
        model.addAttribute("periodos", periodoRepo.findAll());

        // Distribución por carrera (solo dentro del periodo actual)
        List<CarreraCantidadDTO> distribucion = alumnoRepo.contarPorCarreraYPeriodo(periodoId);
        if (distribucion == null) distribucion = new ArrayList<>();

        List<String> labels = distribucion.stream().map(CarreraCantidadDTO::getCarrera).toList();
        List<Long> valores = distribucion.stream().map(CarreraCantidadDTO::getCantidad).toList();

        model.addAttribute("labelsCarrera", labels);
        model.addAttribute("valoresCarrera", valores);

        return "panel";
    }



    @GetMapping("/mi_perfil")
    public String mostrarPerfil(Model model, Principal principal) {
        String correo = principal.getName();
        Usuario usuario = usuarioRepo.findByCorreo(correo).orElse(null);
        if (usuario == null) return "redirect:/login?error";

        Alumno alumno = alumnoRepo.findByUsuario(usuario);
        List<DocumentoResumen> documentos = documentoService.obtenerResumenesPorAlumno(alumno.getId());

        model.addAttribute("alumno", alumno);
        model.addAttribute("documentos", documentos);

        List<Notificacion> notificaciones = notificacionService.obtenerNoLeidas(alumno);
        model.addAttribute("notificaciones", notificaciones);
        notificacionService.marcarTodasComoLeidas(alumno);  // opcional: marca como leídas después de mostrar

        return "mi_perfil";
    }


    @PostMapping("/mi_perfil/guardar")
    public String guardarPerfilAlumno(@ModelAttribute Alumno nuevoAlumno, Authentication auth) {
        String correo = auth.getName();
        Usuario usuario = usuarioRepo.findByCorreo(correo).orElse(null);

        if (usuario != null) {
            nuevoAlumno.setUsuario(usuario);
            alumnoRepo.save(nuevoAlumno);
        }
        return "redirect:/mi_perfil";
    }

    @GetMapping("/alumnos/{id}/documentos")
    public String verDocumentosPorAlumno(@PathVariable Long id, Model model) {
        Alumno alumno = alumnoRepo.findById(id).orElse(null);
        if (alumno == null) return "redirect:/panel";

        List<DocumentoResumen> documentos = documentoService.obtenerResumenesPorAlumno(id);
        model.addAttribute("alumno", alumno);
        model.addAttribute("documentos", documentos);
        return "documentos_admin";
    }
    // Guardar periodo seleccionado en sesión y redirigir a login
    @GetMapping("/seleccionar-periodo")
    public String seleccionarPeriodo(@RequestParam Long id, HttpSession session) {
        session.setAttribute("periodoActivo", id);
        return "redirect:/login";
    }

    // Formulario para crear nuevos periodos (vista opcional)
    @GetMapping("/crear-periodo")
    public String mostrarFormularioPeriodo(Model model) {
        model.addAttribute("periodo", new PeriodoAcademico());
        return "formulario_periodo";
    }

    // Guardar nuevo periodo
    @PostMapping("/crear-periodo")
    public String guardarPeriodo(@ModelAttribute PeriodoAcademico periodo) {
        periodoRepository.save(periodo);
        return "redirect:/dashboard";
    }
    @GetMapping("/admin/documentos")
    public String listarDocumentosPorPeriodo(Model model, HttpSession session) {
        Long periodoId = (Long) session.getAttribute("periodoActivo");
        if (periodoId == null) return "redirect:/";

        List<Documento> documentos = documentoRepo.findByPeriodoId(periodoId);
        model.addAttribute("documentos", documentos);
        return "documentos_admin";
    }
    @PostMapping("/alumnos/editar")
    public String editarAlumno(@ModelAttribute Alumno alumnoForm) {
        Alumno alumnoExistente = alumnoRepo.findById(alumnoForm.getId()).orElse(null);

        if (alumnoExistente != null) {
            alumnoExistente.setNombres(alumnoForm.getNombres());
            alumnoExistente.setApellidos(alumnoForm.getApellidos());
            alumnoExistente.setNumeroControl(alumnoForm.getNumeroControl());
            alumnoExistente.setCarrera(alumnoForm.getCarrera());
            alumnoExistente.setNombreProyecto(alumnoForm.getNombreProyecto());
            alumnoRepo.save(alumnoExistente);
        }

        return "redirect:/panel";
    }

    @GetMapping("/documentos")
    public String vistaGeneracionDocumentos(Model model) {
        List<String> carreras = alumnoRepo.findAll()
                .stream()
                .map(a -> a.getCarrera().toUpperCase())
                .distinct()
                .sorted()
                .toList();

        model.addAttribute("carreras", carreras);
        return "documento"; // Este nombre debe coincidir con documento.html
    }

        @GetMapping("/ingenierias")
        public String mostrarPanel(Model model) {
            return "panel_ingenierias"; // <- Este nombre debe coincidir con el archivo HTML
        }
    }


