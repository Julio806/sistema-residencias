package com.tecnm.residencias.config;

import com.tecnm.residencias.service.UsuarioDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private LoginSuccessHandler loginSuccessHandler;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        // 🟢 Rutas públicas
                        .requestMatchers("/", "/dashboard", "/seleccionar-periodo", "/login", "/registro", "/css/**", "/images/**", "/js/**").permitAll()

                        // 👁 Permitir vista previa de documentos (iframe)
                        .requestMatchers("/documentos/ver/**").permitAll()

                        // 🔐 Rutas protegidas por rol
                        .requestMatchers("/mi_perfil/**").hasRole("ALUMNO")
                        .requestMatchers("/panel/**").hasRole("DIVISION")
                        .requestMatchers("/escolares/**").hasRole("ESCOLARES")
                        .requestMatchers("/vinculacion/**").hasRole("VINCULACION")
                        .requestMatchers("/ingenierias/**").hasRole("INGENIERIAS")

                        // 📄 Documentos (excepto ver) requieren autenticación
                        .requestMatchers("/documentos/**").authenticated()

                        .anyRequest().authenticated()
                )
                .formLogin(login -> login
                        .loginPage("/login")
                        .successHandler(loginSuccessHandler)
                        .permitAll()
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/")
                        .invalidateHttpSession(true)
                        .clearAuthentication(true)
                        .permitAll()
                );

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
